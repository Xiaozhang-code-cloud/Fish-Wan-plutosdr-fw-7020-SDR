.. cmake-module:: ../../Modules/CheckLanguage.cmake
